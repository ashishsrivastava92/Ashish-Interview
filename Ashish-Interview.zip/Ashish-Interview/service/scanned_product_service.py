import uuid

from model.scanned_product import ScannedProduct


class ScannedProductService(object):
    def __init__(self):
        self.scanned_product = dict()

    def add_scanned_product(self, product_id, product_price, scanner):
        scanned_product_id = str(uuid.uuid4())
        scanned_product = ScannedProduct(scanned_product_id, scanner,  product_price,
                                         product_id)
        self.scanned_product[scanned_product_id] = scanned_product
        return scanned_product

