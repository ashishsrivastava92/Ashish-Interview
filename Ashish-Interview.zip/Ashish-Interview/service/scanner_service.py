import uuid
from model.scanner import Scanner
from price_datastore.product_price import PRODUCT_PRICE


class ScannerService(object):
    def __init__(self):
        self.scanner = None    # scanner_id: scanner_obj

    def add_scanner(self):
        scanner_id = uuid.uuid4()
        scanner = Scanner(scanner_id)
        self.scanner = scanner
        return scanner

    def scan_product(self, product_id):
        if product_id not in PRODUCT_PRICE:
            raise KeyError
        return PRODUCT_PRICE[product_id]
