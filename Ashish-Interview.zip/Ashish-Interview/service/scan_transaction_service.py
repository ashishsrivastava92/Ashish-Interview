import uuid
from model.scan_transaction import ScanTransactionState, ScanTransaction


class ScanTransactionService(object):
    def __init__(self):
        self.transaction = None      #id: transaction_obj
        self.transact_products_price = dict()    # pid:2,
        self.transact_product_count = dict()   # pid: count

    def add_transaction(self):
        t_id = uuid.uuid4()
        transaction = ScanTransaction(t_id)
        self.transaction = transaction
        return transaction

    def add_product_to_transaction(self, product_id, product_price):
        if product_id in self.transact_products_price:
            self.transact_product_count[product_id] += 1
            return
        self.transact_products_price[product_id] = product_price
        self.transact_product_count[product_id] = 1
        return True

    def checkout(self, ):
        # compute amount
        amount = 0
        for product_id in self.transact_products_price.keys():
            amount += self.transact_products_price[product_id]*\
                      self.transact_product_count[product_id]
        #transaction- change state
        self.transaction.state = ScanTransactionState.COMPLETED
        return amount

