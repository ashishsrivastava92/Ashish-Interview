from model.scanner import Scanner
from service.scanner_service import ScannerService
from service.scanned_product_service import ScannedProductService
from service.scan_transaction_service import ScanTransactionService


class PriceScanner(object):
    def __init__(self):
        self.Scanner = ScannerService()
        self.Scanned_Product = ScannedProductService()
        self.Transaction = ScanTransactionService()
        self.Transaction.add_transaction()


if __name__ == "__main__":
    price_scanner = PriceScanner()
    product_id = "Apple"
    price_scanner.Scanner.add_scanner()
    price = price_scanner.Scanner.scan_product(product_id)  # scan

    prod = price_scanner.Scanned_Product.add_scanned_product(product_id, price,
                                                             price_scanner.Scanner.scanner)
    # add scanned
    # proct
    price_scanner.Transaction.add_product_to_transaction(product_id, price)
    price_scanner.Transaction.add_product_to_transaction(product_id, price)
    val = price_scanner.Transaction.checkout()
    print(val)
