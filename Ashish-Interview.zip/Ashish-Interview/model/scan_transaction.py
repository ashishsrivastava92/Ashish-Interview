import enum


class ScanTransactionState(enum.Enum):
    # IDLE = 1
    IN_PROGRESS = 1
    COMPLETED = 2
    # FAILED = 3


class ScanTransaction(object):
    def __init__(self, transact_id):
        self.id = transact_id
        self.state = ScanTransactionState.IN_PROGRESS

