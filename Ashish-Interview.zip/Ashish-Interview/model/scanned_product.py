from model.scanner import Scanner


class ScannedProduct(object):
    def __init__(self, scanner_id: str, scanner: Scanner, product_price: float,
                 product_id: str):
        self.id = id
        self.product_price = product_price
        # self.scanner = scanner
        self.product_id = product_id
        # metadata related to prodcut <Product>
