
class Scanner(object):
    def __init__(self, id):
        self.id = id
        # self.name = name
        # metadata
