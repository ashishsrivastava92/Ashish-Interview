PRODUCT_PRICE = {
    "Apple": 345
}
